<div class="text-center justify-content-center align-self-center w-100 p-25">
    <div class="icon fs-100 text-success"><i class="fas fa-mobile-alt"></i></div>
    <div class="detail">
        <div class="title fs-30 fw-6"><?php _e("Scan QR code and get started")?></div>
        <div class="desc fs-16"><?php _e("Use the power of WhatsApp to its fullest! Make WhatsApp Newsletter and automate communication through WhatsApp Chatbot and Autoresponder.")?></div>
    </div>
</div>