<div class="d-flex h-100">
    <div class="justify-content-center align-self-center w-100 p-25">
        <div class="icon fs-45 text-success"><i class="ri-survey-line"></i></div>
        <div class="detail">
            <div class="title fs-25 fw-6"><?php _e("How to use?")?></div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php _e("1. Select an account on left menu")?></li>
                <li class="list-group-item"><?php _e("2. Select Whatsapp feature you want on list")?></li>
            </ul>
        </div>
    </div>
</div>