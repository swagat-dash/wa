
<div class="w-100 p-25 link-generator"> 
        <div class="box-analytics">
            <div class="box-head">
    			<h3 class="text-info title"><?php echo _e('Embeded Code') ?></h3>
    			<div class="description"><?php echo _e('link_instructions') ?></div>
    		</div>
    		
            <div class="col-12 p-10 text-muted code">
               
              <pre class=""><code  class="language-html" id="link_code"></code></pre>
            </div>
        </div>

</div>